var urlRaiz = 'http://localhost/joao/widget/public/importWidgetUltimas';
document.write('<iframe src="'+urlRaiz+'" width="290" height="420" align="middle" frameborder="no" scrolling="no"></iframe>');