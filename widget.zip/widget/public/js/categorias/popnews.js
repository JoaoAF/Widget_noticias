var urlRaiz = 'http://localhost/joao/widget/public/importWidget';
document.write('<iframe src="'+urlRaiz+'?categoria=popnews" width="290" height="420" align="middle" frameborder="no" scrolling="no"></iframe>');
