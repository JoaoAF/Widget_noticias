var urlRaiz = 'http://localhost/joao/widget/public/importWidget';
document.write('<iframe src="'+urlRaiz+'?categoria=diversos" width="290" height="420" align="middle" frameborder="no" scrolling="no" style="background-color: transparent"></iframe>');
