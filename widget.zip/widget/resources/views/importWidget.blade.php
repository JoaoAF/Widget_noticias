@extends('principal')
@section('conteudo')
    <h1>Olá eu sou um ...</h1>

@stop