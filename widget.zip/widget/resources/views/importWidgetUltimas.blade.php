@extends('principal')
@section('conteudo')
    <h1>importWidget - Ultimas Notícias</h1>

@stop