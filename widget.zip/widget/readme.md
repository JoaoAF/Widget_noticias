# Widget_de_notícias

Sistema feito em Laravel Framework e alimentado por um XML, gera um bloco com
três notícias que pode ser importado como widget para qualquer site por meio de um
código de importação gerado pelo sistema.
